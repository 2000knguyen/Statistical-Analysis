/*Name: Kendrick Nguyen
 *Date: 11 February 2021
 *Desc: In this program, we want to create a read file that will then take all of the values within it to then put it in a    *vector. We then want to have the options of displaying either sorted, average, maximum, minimum, or medium grades; as well *as the option to quit. The purpose of this lab is to demonstrate the concepts that we have learned in previous lectures as *well as present lectures. 
*/
#include <iostream>
#include <cstdlib>        //random number function
#include <ctime>          //allows different random numbers
#include "CheckInput.h"   //allows input to be checked, made by professor
#include <fstream>        //allows file reading and writing
#include <vector>         //allows the creation of vectors and the use of its functions
#include <iomanip>        //allows the use of precision
using namespace std;      //gets rid of the need to put ::std

/* PopulateGrades() takes the elements from the grades.txt file and puts it into a vector for use
 @return gradesList returns the vector with all the elements
*/
vector <int> PopulateGrades(){      
  fstream inputFile("grades.txt");    //creates the option to use a file
  vector <int> gradesList;            //init vector
  if (inputFile){
    double value;
    while (inputFile >> value){       //transfer the file's content to the vector
      gradesList.push_back(value);
    }
  }
  return gradesList;                  //returns the vector
}

/* DisplayGrades displays the vector to the user
 @param inputFile gives this function the vector from PopulateGrades()
*/
void DisplayGrades(vector <int> const &inputFile){
  int count = 0;                        
  for (int i = 0; i < 10; i++){             
    for (int i = 0; i < 10; i++){
      cout<<inputFile[count]<<" ";    //Displays the content of the vector
      count++;
      }
    cout<<endl;
  }
}

/* SortList() sorts the vector from least to greatest
 @param sort takes the vector to sort it in the function
*/
void SortList(vector <int> &sort){
  bool swapped = false;
    do{
    swapped = false;
    for(int i = 0; i <sort.size() - 1; i++){
      if (sort[i]>sort[i+1]){
        int swap = sort[i];
        sort[i] = sort[i+1];
        sort[i+1] = swap;
        swapped = true;
      }
    }
  }
  while(swapped);
}

/* SumGrades() takes the vector and adds it all up
 @param gradeSum is the vector from main
 @return the sum of the entire vector
*/
float SumGrades(vector <int> &gradeSum){
  float sum = 0;
  for (int i = 0; i < gradeSum.size(); i++){
    sum += gradeSum[i];                         //For the size of the vector, add each value in it to a variable
  }
  return sum;                                   //returns the Sum
}

/* FindMedian() Finds the median of the vector
 @param Mgrades is the vector from main
 @return the middle index of the vector, if there is two, adds them and divides by 2, then returns
*/
double FindMedian(vector <int> &Mgrades){       
  int index;                           //used to go to specific index of the vector
  double mid1;                         //mid1 checks for even amount of number in the vector
  double mid2;                         //mid2 checks for even amount of number in the vector
  double median = 0.0;                 //init value to return
  if(Mgrades.size() % 2 == 0){         //If the mod of the size comes back as zero, then the total amount of values is even
    index = Mgrades.size() / 2;        //Divides the size by 2
    mid1 = Mgrades[index-1];           //Gets index 49
    mid2 = Mgrades[index];             //Gets index 50
    median = (mid1+mid2) / 2;          //Adds the index together then divide
  } else if (Mgrades.size() % 2 == 1){ //If the size is odd, then just get the middle index
    index = (Mgrades.size()-1)/2;
    median = Mgrades[index];
  }
  return median;                       //Returns the median
}

/* DisplayMenu() is the function that lets the user input values
 @param grades gives the function the vector
*/
void DisplayMenu(vector <int> &grades){
  int option = 0;         //init variable for choosing options
  float sum = 0;          //init the sum variable
  while (1){
    cout << "1. Display Sorted Grades"<<endl;     //Entirety of the display for the user
    cout << "2. Display Average Grade"<<endl;
    cout << "3. Display Maximum Grade"<<endl;
    cout << "4. Display Minimum Grade"<<endl;
    cout << "5. Display Median Grade"<<endl;
    cout << "6. Quit"<<endl;
    cout << "Please select one of the options by typing in a number (1-6): ";
    option = getIntRange(1,6);                    //Checkinput if user does not select correct options
    if (option == 1){
      cout<<"The Sorted Grades are: "<< endl;     //Displays the sorted grades
      DisplayGrades(grades);
    }
    if (option == 2){
      sum = SumGrades(grades);                    //Displays the average of the entirety of the grades
      float avg = sum/grades.size();
      cout<<"The Average Grade is: ";
      cout<<setprecision(3)<<avg <<endl;
    }
    if (option == 3){
      cout << "The maximum grade is: ";           //Displays the maximum grade
      cout<<grades[grades.size()-1];
      cout<<endl;
    }
    if (option == 4){
      cout<<"The minimum grade is: ";             //Displays the minimum grade
      cout<<grades[0];
      cout<<endl;
    }
    if (option == 5){
      cout<<"The median grades is: ";             //Displays the median grade
      cout<<FindMedian(grades);
      cout<<endl;
    }
    if (option == 6){
      cout<<"You have quit."<<endl;               //Quits the program
      break;
    }
    cout<<endl;
  }
}

/* main() function just calls the other functions
*/
int main(){
  vector <int> grades;        //init the vector 
  grades = PopulateGrades();  //populates the vector
  SortList(grades);           //sorts the vector into numerical order
  DisplayMenu(grades);        //calls DisplayMenu Function
}
